import numpy as np

def func1_sysexam12020(t,y1,y2):
    return t**2+30*np.sin(y2)
