def func_example4(t,y):
    dydt=t+2*y
    return dydt