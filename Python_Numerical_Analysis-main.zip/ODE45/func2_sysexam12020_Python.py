import numpy as np

def func2_sysexam12020(t,y1,y2):
    return t+30*np.cos(y1)
