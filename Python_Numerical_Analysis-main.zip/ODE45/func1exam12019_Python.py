import numpy as np

def func1exam12019(t,y1,y2):
    return np.sin(y2)+2*t
