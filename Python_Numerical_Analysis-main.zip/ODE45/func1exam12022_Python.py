import numpy as np

def func1exam12022(t,y1,y2):
    return np.sin(2*np.pi*t)+y1
