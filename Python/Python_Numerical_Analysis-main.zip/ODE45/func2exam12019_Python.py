import numpy as np

def func2exam12019(t,y1,y2):
    return np.cos(y1)-2*t*y2
