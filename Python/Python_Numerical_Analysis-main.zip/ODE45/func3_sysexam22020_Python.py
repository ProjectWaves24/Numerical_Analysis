import numpy as np

def func3_sysexam22020(t,y1,y2,y3):
    return y1+y2+50*np.cos(y1)
