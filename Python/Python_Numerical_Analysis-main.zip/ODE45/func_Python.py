def func(t,y):
    return y