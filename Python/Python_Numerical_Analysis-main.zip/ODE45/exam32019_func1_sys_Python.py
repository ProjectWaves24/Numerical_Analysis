def exam32019_func1_sys(t,y1,y2):
    return 5*y1-2*y2+2*t