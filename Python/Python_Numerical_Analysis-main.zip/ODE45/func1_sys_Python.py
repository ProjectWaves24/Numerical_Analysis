def func1_sys(t,y1,y2):
    return y2+2*t
