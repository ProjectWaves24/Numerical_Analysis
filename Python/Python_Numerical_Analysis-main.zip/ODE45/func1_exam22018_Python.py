def func1_exam22018(t,y1,y2):
    return y2
