def func_exam22018(t,y):
    y1,y2=y
    dydt=[y2,y1+y2]
    return dydt