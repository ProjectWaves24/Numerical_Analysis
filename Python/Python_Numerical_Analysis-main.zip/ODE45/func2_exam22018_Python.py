def func2_exam22018(t,y1,y2):
    return y1+y2
