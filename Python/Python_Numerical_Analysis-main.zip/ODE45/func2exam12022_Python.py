import numpy as np

def func2exam12022(t,y1,y2):
    return np.cos(2*np.pi*t)-y2
