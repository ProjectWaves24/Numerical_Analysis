def exam32019_func2_sys(t,y1,y2):
    return y1+y2+t+1