def func_example6(t,y):
    #dydt=t+2*y
    dydt=-20*y
    return dydt