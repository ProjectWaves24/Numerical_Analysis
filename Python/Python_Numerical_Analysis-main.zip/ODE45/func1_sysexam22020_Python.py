import numpy as np

def func1_sysexam22020(t,y1,y2,y3):
    return t**2+50*np.sin(y2)+y3
